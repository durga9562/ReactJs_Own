<img align="right" width="200" src="https://img.icons8.com/color/452/firebase.png" />

# Firebase Auth Methods ✨️

<a href="https://github.com/saviomartin/firebase-auth-methods/blob/master/LICENSE" target="blank">
<img src="https://img.shields.io/github/license/saviomartin/firebase-auth-methods?style=flat-square" alt="firebase-auth-methods licence" />
</a>
<a href="https://github.com/saviomartin/firebase-auth-methods/fork" target="blank">
<img src="https://img.shields.io/github/forks/saviomartin/firebase-auth-methods?style=flat-square" alt="firebase-auth-methods forks"/>
</a>
<a href="https://github.com/saviomartin/firebase-auth-methods/stargazers" target="blank">
<img src="https://img.shields.io/github/stars/saviomartin/firebase-auth-methods?style=flat-square" alt="firebase-auth-methods stars"/>
</a>
<a href="https://github.com/saviomartin/firebase-auth-methods/issues" target="blank">
<img src="https://img.shields.io/github/issues/saviomartin/firebase-auth-methods?style=flat-square" alt="firebase-auth-methods issues"/>
</a>
<a href="https://github.com/saviomartin/firebase-auth-methods/pulls" target="blank">
<img src="https://img.shields.io/github/issues-pr/saviomartin/firebase-auth-methods?style=flat-square" alt="firebase-auth-methods pull-requests"/>
</a>

These are some of the auth methods I developed with React Js. I used to write blog to explain the process. [http://savio.xyz/](http://savio.xyz/) - Checkout my blog 👨‍💻

> Feel free to use this firebase auth methods! 🥁
