import {Component} from 'react'

import './index.css'

class SpotifyClone extends Component {
  render() {
    return <div>SPOTIFY CLONE</div>
  }
}

export default SpotifyClone
